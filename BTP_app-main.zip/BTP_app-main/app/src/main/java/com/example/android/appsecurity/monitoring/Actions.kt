package com.example.android.appsecurity.monitoring

enum class Actions {
    START,
    STOP
}