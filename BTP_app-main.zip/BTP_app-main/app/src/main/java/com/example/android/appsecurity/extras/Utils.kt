package com.example.android.appsecurity.extras

import android.util.Log

fun logBTP(msg: String) {
    Log.d("BTP_logs", msg)
}
